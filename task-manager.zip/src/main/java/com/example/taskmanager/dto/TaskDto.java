package com.example.taskmanager.dto;

import lombok.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskDto {
    private String title;
    private String assignee;
    private String status;
    private LocalDate date;
}
