package com.example.taskmanager.repository;

import com.example.taskmanager.entity.Task;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    @Query("SELECT t FROM Task t WHERE t.assignee = :assignee AND t.date BETWEEN :start AND :end AND t.status <> 'CANCELLED'")
    List<Task> findTasksInRangeWithoutCancelled(@Param("assignee") String assignee,
                                                @Param("start") LocalDate start,
                                                @Param("end") LocalDate end);
}
