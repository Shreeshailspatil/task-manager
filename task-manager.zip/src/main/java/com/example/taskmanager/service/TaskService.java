package com.example.taskmanager.service;

import com.example.taskmanager.dto.TaskDto;
import com.example.taskmanager.entity.Task;
import com.example.taskmanager.mapper.TaskMapper;
import com.example.taskmanager.repository.TaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TaskService {
    private final TaskRepository taskRepository;
    private final TaskMapper taskMapper;

    public List<TaskDto> getTasks(String assignee, LocalDate start, LocalDate end) {
        return taskRepository.findTasksInRangeWithoutCancelled(assignee, start, end)
                .stream()
                .map(taskMapper::toDto)
                .collect(Collectors.toList());
    }

    public void reassignTask(Long taskId, String newAssignee) {
        Task oldTask = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        oldTask.setStatus("CANCELLED");
        taskRepository.save(oldTask);

        Task newTask = new Task();
        newTask.setTitle(oldTask.getTitle());
        newTask.setAssignee(newAssignee);
        newTask.setStatus("PENDING");
        newTask.setDate(oldTask.getDate());

        taskRepository.save(newTask);
    }
}
